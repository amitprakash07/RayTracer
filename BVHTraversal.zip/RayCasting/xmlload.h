#ifndef __XMLLOAD_H
#define __XMLLOAD_H

int LoadScene(const char *filename);

#endif
