#ifndef __VIEWPORT_H
#define __VIEWPORT_H

void ShowViewport();
void BeginRender();	// Called to start rendering (renderer must run in a separate thread)
void StopRender();	// Called to end rendering (if it is not already finished)

#endif
